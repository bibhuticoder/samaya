<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style>
body {
  margin: 0;
  padding: 0;
  font-family: "Mukta", sans-serif;
}
#app {
  position: absolute;
  width: 100%;
  height: 100%;
}
</style>

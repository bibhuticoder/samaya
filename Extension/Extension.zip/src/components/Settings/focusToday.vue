<template>
<div>
<h1>Daily Goal Settings</h1>
</div>
</template>
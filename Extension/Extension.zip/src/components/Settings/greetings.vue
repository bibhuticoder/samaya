<template>
<div>
<h1>Greetings Settings</h1>
</div>
</template>